const people=[
{id:1,name:"Aarav",age:26,city:"Delhi",about:"Coffee, live music and weekend walks.",interests:["Music","Food"],initial:"A"},
{id:2,name:"Meera",age:24,city:"Lucknow",about:"Books, art galleries and meaningful conversations.",interests:["Books","Travel"],initial:"M"},
{id:3,name:"Kabir",age:28,city:"Prayagraj",about:"Fitness, food trails and exploring new places.",interests:["Fitness","Food"],initial:"K"},
{id:4,name:"Anaya",age:25,city:"Jaipur",about:"Travel, photography and indie music.",interests:["Travel","Music"],initial:"A"}];
let liked=new Set(),matches=new Set();
const $=id=>document.getElementById(id);
$("enter").onclick=()=>{if(!$("adult").checked||!$("rules").checked){alert("Please confirm both 18+ age and community rules.");return}$("gate").hidden=true;$("app").hidden=false;render()};
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"));b.classList.add("active");document.querySelectorAll(".tab").forEach(t=>t.hidden=true);$(b.dataset.tab).hidden=false;if(b.dataset.tab==="matches")renderMatches()});
function render(){const city=$("cityFilter").value.toLowerCase(),interest=$("interestFilter").value;const list=people.filter(p=>(!city||p.city.toLowerCase().includes(city))&&(!interest||p.interests.includes(interest)));$("cards").innerHTML=list.map(p=>`<article class="person"><div class="avatar">${p.initial}</div><h3>${p.name}, ${p.age}</h3><div class="muted">${p.city} • Demo profile</div><p>${p.about}</p><div class="chips">${p.interests.join(" · ")}</div><div class="actions"><button class="secondary" onclick="pass(${p.id})">Pass</button><button onclick="like(${p.id})">Like</button></div></article>`).join("")||'<div class="empty">No demo profiles match these filters.</div>'}
$("cityFilter").oninput=render;$("interestFilter").onchange=render;
window.like=id=>{liked.add(id);if(id===2||id===3)matches.add(id);render();alert("Demo like recorded. A real match requires mutual interest.")};
window.pass=id=>{liked.delete(id);render()};
function renderMatches(){$("matchList").innerHTML=matches.size?[...matches].map(id=>{let p=people.find(x=>x.id===id);return `<div class="person"><b>${p.name}</b><p>${p.city} • Demo mutual match</p><p class="muted">Chat is not connected in this prototype.</p><button class="secondary" onclick="alert('Demo only: no messages are sent or stored.')">Open demo chat</button></div>`}).join(""):'When two people like each other, a match appears here.'}
$("saveProfile").onclick=()=>{$("profileStatus").textContent=$("displayName").value&&$("myCity").value?"Demo profile saved on this page only. It is not uploaded or shared.":"Please add a display name and city."};
$("reportInfo").onclick=()=>{$("reportText").textContent="This prototype does not send reports to a moderation team. In a live app, reporting must connect to a staffed safety process. For immediate danger, contact local emergency services."};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));