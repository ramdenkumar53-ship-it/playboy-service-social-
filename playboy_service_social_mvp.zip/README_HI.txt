PLAYBOY SERVICE SOCIAL — ANDROID MVP STARTER

यह एक static PWA demo है, live dating service नहीं।
इसमें profiles demo हैं; वास्तविक user accounts, database, chat, identity verification,
payments, reporting/moderation backend या real bookings जुड़े नहीं हैं।

Android से चलाने का सबसे आसान तरीका:
1. ZIP extract करें।
2. GitHub में एक नया public repository बनाएं: playboy-service-social
3. Upload files पर जाएं और इस folder की सभी files upload करें।
4. Repository Settings > Pages खोलें।
5. Deploy from a branch चुनें; Branch: main और folder: /(root) चुनकर Save करें।
6. कुछ मिनट बाद GitHub Pages URL खुलेगा। Android Chrome में खोलें।
7. Chrome menu > Add to Home screen से फोन पर app जैसा shortcut बनाएं।

सुरक्षा:
- यह prototype केवल 18+ social connection के लिए है।
- Escorting, prostitution, sexual services या paid sexual encounters की सुविधा नहीं है।
- Demo profile, likes और matches केवल browser में अस्थायी हैं।
- Public launch से पहले secure authentication, database, server-side moderation,
  age assurance, privacy policy, terms, data deletion और local legal review जरूरी हैं।
- किसी भी तरह की ID image या sensitive personal information इस demo में न डालें।
